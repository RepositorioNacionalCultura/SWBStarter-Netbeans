
        var mediaquery = window.matchMedia("(max-width:639px)"),
        content = document.querySelector(".content");
        function openNav() {
            document.getElementById("offcanvasAbre").style.display = "none";
            document.getElementById("offcanvasCierra").style.display = "inline-block";
            if (mediaquery.matches) {
                    document.getElementById("sidebar").style.width = "40%";
                    document.getElementById("contenido").style.width = "60%";
                    document.getElementById("contenido").style.marginLeft = "40%";
                } else {
                    document.getElementById("sidebar").style.width = "25%";
                    document.getElementById("contenido").style.width = "75%";
                    document.getElementById("contenido").style.marginLeft = "25%";
                }
            
        }
        function closeNav() {
            document.getElementById("offcanvasAbre").style.display = "inline-block";
            document.getElementById("offcanvasCierra").style.display = "none";
            document.getElementById("sidebar").style.width = "0";
            document.getElementById("contenido").style.width = "100%";
            document.getElementById("contenido").style.marginLeft = "0%";
            
        }