$(document).ready(function() {
            var altura = $('.busca').offset().top;
            $(window).on('scroll', function() {
                if ($(window).scrollTop() > altura) {
                    $('.busca').addClass('displaynone');  
                    $('.nav-origen').addClass('gris21-bg');
                    $('.buscanav').removeClass('visiblehidden');
                } else {
                    $('.busca').removeClass('displaynone');
                    $('.nav-origen').removeClass('gris21-bg');
                    $('.buscanav').addClass('visiblehidden');
                    
                }
            });
        });