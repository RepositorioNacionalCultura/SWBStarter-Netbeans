$(document).ready(function() {
            var altura = $('.busca').offset().top;
            $(window).on('scroll', function() {
                if ($(window).scrollTop() > altura) {
                    $('.busca').addClass('busca-fixed');
                    $('.busca1').addClass('buscatop');
                    $('.busca2').addClass('buscatop');
                    $('.busca3').addClass('buscatop');
                    $('.busca4').addClass('buscatop');
                    $('.nav-origen').addClass('buscatop');
                    $('.nav-clon').addClass('buscatop');
                } else {
                    $('.busca').removeClass('busca-fixed');
                    $('.busca1').removeClass('buscatop');
                    $('.busca2').removeClass('buscatop');
                    $('.busca3').removeClass('buscatop');
                    $('.busca4').removeClass('buscatop');
                    $('.nav-origen').removeClass('buscatop');
                    $('.nav-clon').removeClass('buscatop');
                }
            });
        });